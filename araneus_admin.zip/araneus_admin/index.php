<?php

header('Location: public/');

?>