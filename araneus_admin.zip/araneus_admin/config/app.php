<?php
define('APP_NAME', 'Araneus Edutech Admin');
define('APP_URL', '/araneus_admin/public/');
define('SESSION_NAME', 'araneus_admin_sess');
define('UPLOAD_PATH', APP_ROOT . '../uploads/');
